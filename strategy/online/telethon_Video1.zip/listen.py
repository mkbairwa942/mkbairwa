from telethon import TelegramClient, events
from config import *
client = TelegramClient('session_name', api_id, api_hash)

@client.on(events.NewMessage)
async def my_event_handler(event):
    if 'hello' in event.raw_text:
        await event.reply('hi!')


@client.on(events.NewMessage(chats=-3456789))
async def my_event_handler(event):
    print(event.raw_text)

client.start()
client.run_until_disconnected()