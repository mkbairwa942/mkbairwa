from telethon import TelegramClient, events
import re
from config import *
client = TelegramClient('session_name', api_id, api_hash)


# ADD order placement logic as per your broker

def  placeOrder(transType, symbol, SL, target):
    print(f'Place {transType} Order {symbol} SL {SL} target {target}')  

def check_statement(statement):
    regex = r'\b(?:buy|sell)\b.*\bsl\b.*\btarget\b'
    match = re.search(regex, statement,re.IGNORECASE)
    if match:
        return True
    else:
        return False

def find_next_word_after_word(statement, target_word):
    regex = r'\b{}\b\s+(\w+)'.format(target_word)
    match = re.search(regex, statement, re.IGNORECASE)
    if match:
        return match.group(1)
    else:
        return None


@client.on(events.NewMessage(chats=-4567898))
async def my_event_handler(event):
    statement = event.raw_text
    print(statement)
    if check_statement(statement): 
        await client.send_message(987654567, f'Got Signal:  {statement}')
        print(f'Pattern match for entry {statement} ')
        sl = find_next_word_after_word(statement,'sl')
        target = find_next_word_after_word(statement,'target')
        isBuy = find_next_word_after_word(statement,'buy')
        isSell = find_next_word_after_word(statement,'sell')
        if isBuy :
            placeOrder('BUY',isBuy, sl, target)
        elif isSell:
            placeOrder('SELL',isSell, sl, target)

client.start()
client.run_until_disconnected()